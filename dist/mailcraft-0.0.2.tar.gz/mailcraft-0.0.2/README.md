# Mail Craft

A easy way to create your mail server and and mail templates.

Currently only testing its publishing.